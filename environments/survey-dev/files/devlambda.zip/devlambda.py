import logging
import requests

logger = logging.getLogger(__name__)


def handler(event, context):
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

    try:
        response = requests.head(
            "https://www.google.com", timeout=5
        )
        if not response.ok:
            raise Exception(
                f"Non OK response: {response.status_code} {response.content}"
            )
    except requests.exceptions.Timeout as exc:
        logger.error(f"HEAD request to google timed out: {exc}")
    except Exception as exc:
        logger.error(f"Unhandled exception: {exc}")
    else:
        logger.info(
            f"HEAD responese ok, date header: {response.headers['date']}"
        )
